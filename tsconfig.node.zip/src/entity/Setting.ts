export default interface Setting {
  autoChangeUser: boolean,
  autoPlayAudio: boolean,
  autoEndGemRound: boolean,
}